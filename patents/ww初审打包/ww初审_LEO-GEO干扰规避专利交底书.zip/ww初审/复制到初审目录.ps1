# 将本目录复制到本机初审目录
# 用法：在解压后的 ww初审 目录中，右键“使用 PowerShell 运行”，或：
#   powershell -ExecutionPolicy Bypass -File .\复制到初审目录.ps1

$dest = "D:\work\专利\ww初审"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item -Path "$PSScriptRoot\*" -Destination $dest -Recurse -Force
Write-Host "已复制到 $dest"
explorer $dest
